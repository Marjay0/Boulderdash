﻿// Activité Synthèse 420-KB1-LG
// Version 1.0: novembre 2019 - Traduit du C++ au C# 
// Version 1.1: 2 décembre 2019 - Modification du namespace
//                              - Modification de la rotation quand Rockford ne fait rien 
// Version 1.2: 3 décembre 2019 - Spécification du Framework .Net 4.7.2
//                              - Changement du nom de l'assembly 
// Version 1.3: 22 novembre 2022 - Élimination de la partie "matrice de transformation"

//Modifié par Jayden Marchica le 2/12/2022

using System;
using System.Threading;
using System.IO;
using SFML.Graphics;
using SFML.Window;
using SFML.System;
using SFML.Audio;
using System.Threading.Tasks;
using System.ComponentModel.Design;

namespace Boulderdash
{
    class Program
    {
        // ATTENTION! LE CODE CI-DESSOUS VOUS EST FOURNI ET NE DOIT PAS ÊTRE MODIFIÉ!
        // **************************************************************************

        const int NbColonnes = 40;          // Nombre de cases par ligne
        const int NbLignes = 22;            // Nombre de lignes
        const int NbPixelsParCase = 24;     // Nombre de pixels d'une case
        const int VitessePapillon = 5;

        // Représente le contenu d'une case du tableau
        // Vide, Mur, Terre, Rocher, RocherTombant, Diamant
        enum Objet { V, M, T, R, RT, D };

        // Représente les directions de déplacement de l'ennemi
         enum Direction { Gauche, Haut, Droite, Bas };

        /// <summary>
        /// La classe Personnage sert à créer Boulderdash et son ennemi
        /// </summary>
        class Personnage
        {
            /// <summary>
            /// Constructeur du personnage: pour créer un personnage, utilisez l'opérateur new
            /// </summary>
            /// <param name="fichierImage">Nom du fichier image</param>
            /// <param name="x">Position initiale en x</param>
            /// <param name="y">Position initiale en y</param>
            /// <param name="dir">Direction intiale</param>
            public Personnage(string fichierImage, int x, int y, Direction dir)
            {
                X = x;
                Y = y;
                Direction = dir;
                Texture = new Texture(fichierImage);
                Sprite = new Sprite(Texture);
            }

            /// <summary>
            /// Utilisez la méthode Afficher du personnage pour afficher le personnage
            /// dans une fenêtre
            /// </summary>
            /// <param name="fenetre">Objet représentant la fenêtre</param>
            /// <param name="echelle">Facteur multiplicatif permettant de passer de la position
            /// dans le tableau 2D à la position dans l'image</param>
            public void Afficher(RenderWindow fenetre, float nbPixelsParCase)
            {
                Vector2f position = new Vector2f(X * nbPixelsParCase, Y * nbPixelsParCase);
                Sprite.Position = position;
                fenetre.Draw(Sprite);
            }
            /// <value>
            /// Utilisez la propriété X afin de modifier la position horizontale
            /// </value>     
            public int X { get; set; }
            /// <value>
            /// Utilisez la propriété Y afin de modifier la position verticale
            /// </value>     
            public int Y { get; set; }
            /// <value>
            /// Utilisez la propriété Direction afin de conserver la direction du personnage
            /// </value>     
            public Direction Direction { get; set; }

            #region
            private Texture Texture { get; set; }
            private Sprite Sprite { get; set; }
                      
            #endregion
        }
        
        #region
        static Objet[,] ChargerCarteJeu()
        {
            Objet[,] carte = new Objet[NbLignes, NbColonnes];
            using (StreamReader reader = new StreamReader("Boulderdash.csv"))
            {
                for (int indiceLigne = 0; indiceLigne < NbLignes; indiceLigne++)
                {
                    string line = reader.ReadLine();
                    for (int indiceColonne = 0; indiceColonne < NbColonnes; indiceColonne++)
                    {
                        string[] values = line.Split(',');
                        carte[indiceLigne, indiceColonne] = (Objet)Enum.Parse(typeof(Objet), values[indiceColonne]);
                    }
                }

            }
            return carte;
        }
        #endregion
        static void Main(string[] args)
        {
            Objet[,] carte = ChargerCarteJeu(); // On charge la carte (fonction déjà écrite, cette ligne ne devrait pas changer)

            // **************************************************************************

           
            //Affichage de la fenêtre
            VideoMode mode = new VideoMode(NbColonnes * NbPixelsParCase, NbLignes * NbPixelsParCase);
            RenderWindow window = new RenderWindow(mode, "Boulderdash");

            //Affichage des textures
            Texture terre = new Texture("images/terre24.bmp");
            Sprite sTerre = new Sprite(terre);

            Texture mur = new Texture("images/mur24.bmp");
            Sprite sMur = new Sprite(mur);

            Texture roche = new Texture("images/roche24.bmp");
            Sprite sRoche = new Sprite(roche);

            Texture diamant = new Texture("images/diamant24.bmp");
            Sprite sDiamant = new Sprite(diamant);

            Texture gagne = new Texture("images/gagne24.bmp");
            Sprite sGagne = new Sprite(gagne);

            Texture perdu = new Texture("images/perdu24.bmp");
            Sprite sPerdu = new Sprite(perdu);

            //Affichage des personnages
            Personnage rockford = new Personnage("images/heros24.bmp", 3, 2, Direction.Droite);

            Personnage ametooth = new Personnage("images/ametooth24.bmp", 10, 5, Direction.Droite);

            Personnage papillon = new Personnage("images/papillon24.bmp", 2, 16, Direction.Haut);

            //Compte les diamants pour gagner
            int NbrDiam1 = 19;
            int compteDiamant = 0;

            //Prends en note le niveau
            int niveau = 1;

            //Variable pour fermer la fenêtre sans break
            bool closeWindow = false;

            //Variable si Personnage est en vie/bouge
            bool aliveRockford = true;
            bool alivePapillon = true;
            bool aliveAmetooth = true;

            //Variable pour faire avancer le papillon plus lentement
            int papillonMove = 1;

            //Attendre entre les niveaux
            const int NextLevel = 300;//Nombre de boucles avant que le niveau change (10 = environ 1s) 
            int levelwaiting = 0;

            while (!(Keyboard.IsKeyPressed(Keyboard.Key.Escape))
                || closeWindow == true)
            {
                window.DispatchEvents();
                window.Clear();


                //Modifie la carte pour les rochers
                ModifierRochers(carte, rockford, ametooth);


                //Bouge Rockford
                if (aliveRockford)
                {
                    BougerPersonnage(carte, rockford, Keyboard.Key.W, Keyboard.Key.S, Keyboard.Key.A, Keyboard.Key.D);
                }

                //Bouge Ametooth
                if (aliveAmetooth)
                {
                    BougerPersonnage(carte, ametooth, Keyboard.Key.Up, Keyboard.Key.Down, Keyboard.Key.Left, Keyboard.Key.Right);
                }

                //Bouge le papillon
                papillonMove++;
                if (papillonMove == VitessePapillon
                    && alivePapillon)
                {
                    BougerPapillon(carte, papillon);
                    papillonMove = 1;
                }

                //Afficher la carte
                for (int i = 0; i < NbLignes; i++)
                {
                    for (int j = 0; j < NbColonnes; j++)
                    {
                        switch (niveau)
                        {
                            case 1:
                                switch (carte[i, j])
                                {
                                    case Objet.M: //Murs
                                        AfficherSprite(sMur, window, j, i);
                                        break;
                                    case Objet.T: //Terre
                                        AfficherSprite(sTerre, window, j, i);
                                        break;
                                    case Objet.D: //Diamants
                                        AfficherSprite(sDiamant, window, j, i);
                                        break;
                                    case Objet.R:
                                        case Objet.RT: //Rochers et Rochers Tombants
                                            AfficherSprite(sRoche, window, j, i);
                                            break;
                                }
                                break;
                        }
                    }
                }

                //Enleve la terre et les diamants sous les pieds des personnages
                compteDiamant = EnleverTerreSousPersonnage(carte, rockford, compteDiamant);
                compteDiamant = EnleverTerreSousPersonnage(carte, ametooth, compteDiamant);


                //Affiche le papillon
                papillon.Afficher(window, NbPixelsParCase);

                //Affiche Rockford s'il est vivant
                if (TrouverSiPersonnageVivant(carte, rockford, papillon)
                    && aliveRockford)
                {
                    rockford.Afficher(window, NbPixelsParCase);
                }
                else
                {
                    aliveRockford = false;
                }

                //Affiche Ametooth s'il est vivant
                if (TrouverSiPersonnageVivant(carte, ametooth, papillon)
                    && aliveAmetooth)
                {
                    ametooth.Afficher(window, NbPixelsParCase);
                }
                else
                {
                    aliveAmetooth = false;
                }

                //Affiches le message de perte si tous les personnages sont morts
                if (!aliveRockford && !aliveAmetooth)
                {
                    AfficherFin(sPerdu, window);
                    alivePapillon = false; //Seulement pour qu'ils ne bouge pas
                }

                //Affiche le message gagnant si les diamants sont récoltés
                if (compteDiamant == NbrDiam1)
                {
                    AfficherFin(sGagne, window);
                    aliveRockford = false; //Seulement pour qu'ils ne bouge pas
                    aliveAmetooth = false;
                    alivePapillon = false;
                }

                window.Display();
                
                //Attend X millisecondes pour que les touches soit de rapidité humaine
                System.Threading.Thread.Sleep(100);
            }
        }


        /// <summary>
        /// Modifies les rochers selon la position de ceux-ci et de deux personnages
        /// </summary>
        /// <param name="carte">Le tableau du niveau</param>
        /// <param name="rockford">Le premier personnage</param>
        /// <param name="ametooth">Le deuxième personnage</param>
        static void ModifierRochers(Objet[,] carte, Personnage rockford, Personnage ametooth)
        {
            for (int i = 0; i < NbLignes; i++)
            {
                for (int j = 0; j < NbColonnes; j++)
                {
                    switch (carte[i, j])
                    {
                        case Objet.R:
                            if (carte[i + 1, j] == Objet.V //Rocher qui tombe dans le vide
                                && (i + 1, j) != (rockford.Y, rockford.X)
                                && (i + 1, j) != (ametooth.Y, ametooth.X)
                                || carte[i + 1, j] == Objet.R //Éboulement à la droite
                                && carte[i, j + 1] == Objet.V
                                && carte[i + 1, j + 1] == Objet.V
                                || carte[i + 1, j] == Objet.R //Éboulement à la gauche
                                && carte[i, j - 1] == Objet.V
                                && carte[i + 1, j - 1] == Objet.V)
                            {
                                carte[i, j] = Objet.RT;
                            }
                            break;
                        case Objet.RT:
                            if (carte[i + 1, j] == Objet.V) //Tombe
                            {
                                carte[i, j] = Objet.V;
                                carte[i + 1, j] = Objet.RT;
                            }
                            else if (carte[i + 1, j] == Objet.R //Éboulement à droite
                                && carte[i, j + 1] == Objet.V
                                && carte[i + 1, j + 1] == Objet.V)
                            {
                                carte[i, j] = Objet.V;
                                carte[i, j + 1] = Objet.RT;
                            }
                            else if (carte[i + 1, j] == Objet.R //Éboulement à la gauche
                                && carte[i, j - 1] == Objet.V
                                && carte[i + 1, j - 1] == Objet.V)
                            {
                                carte[i, j] = Objet.V;
                                carte[i, j - 1] = Objet.RT;
                            }
                            else
                            {
                                carte[i, j] = Objet.R;
                            }
                            break;
                    }
                }
            }
        }
        /// <summary>
        /// Affiches un sprite à une certaine position dans le niveau
        /// </summary>
        /// <param name="sprite">Le sprite</param>
        /// <param name="window">La fenêtre d'affichage</param>
        /// <param name="x">La postion en X</param>
        /// <param name="y">La postion en Y</param>
        static void AfficherSprite(Sprite sprite, RenderWindow window, int x, int y)
        {
            sprite.Position = new Vector2f(x * NbPixelsParCase, y * NbPixelsParCase);
            window.Draw(sprite);
        }
        /// <summary>
        /// Affiche le sprite de fin de niveau à une position prédéterminée
        /// </summary>
        /// <param name="sprite">Le sprite de fin de niveau (Sprite)</param>
        /// <param name="window">La fenêtre d'affichage</param>
        static void AfficherFin(Sprite sprite, RenderWindow window)
        {
            sprite.Position = new Vector2f(95, 71);
            window.Draw(sprite);
        }
        /// <summary>
        /// Bouges le personnage choisi selon les inputs de l'utilisateur
        /// </summary>
        /// <param name="carte">Le tableau du niveau</param>
        /// <param name="rockford">Le personnage à bouger (Personnage)</param>
        /// <param name="Haut">La touche pour aller vers le haut (Keyboard.Key)</param>
        /// <param name="Bas">La touche pour aller vers le bas (Keyboard.Key)</param>
        /// <param name="Gauche">La touche pour aller vers la gauche (Keyboard.Key)</param>
        /// <param name="Droite">La touche pour aller vers la droite (Keyboard.Key)</param>
        static void BougerPersonnage(Objet[,] carte, Personnage rockford, Keyboard.Key Haut, Keyboard.Key Bas, Keyboard.Key Gauche, Keyboard.Key Droite)
        {
            if (Keyboard.IsKeyPressed(Haut) //Bouge Rockford (Haut)
                    && carte[rockford.Y - 1, rockford.X] != Objet.M //Sans passer à travers les murs
                    && carte[rockford.Y - 1, rockford.X] != Objet.R //Ou les rochers
                    && carte[rockford.Y - 1, rockford.X] != Objet.RT) //Ou les rochers tombants
            {
                rockford.Y--;
            }
            else if (Keyboard.IsKeyPressed(Bas) //Bas
                && carte[rockford.Y + 1, rockford.X] != Objet.M
                && carte[rockford.Y + 1, rockford.X] != Objet.R)
            {
                rockford.Y++;
            }
            else if (Keyboard.IsKeyPressed(Droite) //Droite
                && carte[rockford.Y, rockford.X + 1] != Objet.M)
            {
                if (carte[rockford.Y, rockford.X + 1] == Objet.R //Pousse un rocher si la case suivante est vide
                    && carte[rockford.Y, rockford.X + 2] == Objet.V)
                {
                    carte[rockford.Y, rockford.X + 2] = Objet.R;
                    carte[rockford.Y, rockford.X + 1] = Objet.V;
                    rockford.X++;
                }
                else if (carte[rockford.Y, rockford.X + 1] == Objet.V
                    || carte[rockford.Y, rockford.X + 1] == Objet.T
                    || carte[rockford.Y, rockford.X + 1] == Objet.D)
                {
                    rockford.X++;
                }
            }
            else if (Keyboard.IsKeyPressed(Gauche) //Gauche
                && carte[rockford.Y, rockford.X - 1] != Objet.M)
            {
                if (carte[rockford.Y, rockford.X - 1] == Objet.R
                    && carte[rockford.Y, rockford.X - 2] == Objet.V)
                {
                    carte[rockford.Y, rockford.X - 2] = Objet.R;
                    carte[rockford.Y, rockford.X - 1] = Objet.V;
                    rockford.X--;
                }
                else if (carte[rockford.Y, rockford.X - 1] == Objet.V
                    || carte[rockford.Y, rockford.X - 1] == Objet.T
                    || carte[rockford.Y, rockford.X - 1] == Objet.D)
                {
                    rockford.X--;
                }
            }
        }
        /// <summary>
        /// Bouges le papillon en longeant le mur de gauche
        /// </summary>
        /// <param name="carte">Le tableau du niveau</param>
        /// <param name="papillon">Le papillon (Personnage)</param>
        static void BougerPapillon(Objet[,] carte, Personnage papillon)
        {
            switch (papillon.Direction)
            {
                case Direction.Haut:
                    if (carte[papillon.Y, papillon.X - 1] == Objet.V)
                    {
                        papillon.X--;
                        papillon.Direction = Direction.Gauche;
                    }
                    else if (carte[papillon.Y - 1, papillon.X] == Objet.V)
                    {
                        papillon.Y--;
                    }
                    else if (carte[papillon.Y, papillon.X + 1] == Objet.V)
                    {
                        papillon.X++;
                        papillon.Direction = Direction.Droite;
                    }
                    else if (carte[papillon.Y + 1, papillon.X] == Objet.V)
                    {
                        papillon.Y++;
                        papillon.Direction = Direction.Bas;
                    }
                    break;
                case Direction.Gauche:
                    if (carte[papillon.Y + 1, papillon.X] == Objet.V)
                    {
                        papillon.Y++;
                        papillon.Direction = Direction.Bas;
                    }
                    else if (carte[papillon.Y, papillon.X - 1] == Objet.V)
                    {
                        papillon.X--;
                    }
                    else if (carte[papillon.Y - 1, papillon.X] == Objet.V)
                    {
                        papillon.Y--;
                        papillon.Direction = Direction.Haut;
                    }
                    else if (carte[papillon.Y, papillon.X + 1] == Objet.V)
                    {
                        papillon.X++;
                        papillon.Direction = Direction.Droite;
                    }
                    break;
                case Direction.Bas:
                    if (carte[papillon.Y, papillon.X + 1] == Objet.V)
                    {
                        papillon.X++;
                        papillon.Direction = Direction.Droite;
                    }
                    else if (carte[papillon.Y + 1, papillon.X] == Objet.V)
                    {
                        papillon.Y++;
                    }
                    else if (carte[papillon.Y, papillon.X - 1] == Objet.V)
                    {
                        papillon.X--;
                        papillon.Direction = Direction.Gauche;
                    }
                    else if (carte[papillon.Y - 1, papillon.X] == Objet.V)
                    {
                        papillon.Y--;
                        papillon.Direction = Direction.Haut;
                    }
                    break;
                case Direction.Droite:
                    if (carte[papillon.Y - 1, papillon.X] == Objet.V)
                    {
                        papillon.Y--;
                        papillon.Direction = Direction.Haut;
                    }
                    else if (carte[papillon.Y, papillon.X + 1] == Objet.V)
                    {
                        papillon.X++;
                    }
                    else if (carte[papillon.Y + 1, papillon.X] == Objet.V)
                    {
                        papillon.Y++;
                        papillon.Direction = Direction.Bas;
                    }
                    else if (carte[papillon.Y, papillon.X - 1] == Objet.V)
                    {
                        papillon.X--;
                        papillon.Direction = Direction.Gauche;
                    }
                    break;
            }
        }
        /// <summary>
        /// Enlève la terre et compte les diamants
        /// </summary>
        /// <param name="carte">Le tableau du niveau</param>
        /// <param name="rockford">Le personnage</param>
        /// <param name="diam">Le compte de diamants récoltés</param>
        /// <returns></returns>
        static int EnleverTerreSousPersonnage(Objet[,] carte, Personnage rockford, int diam)
        {
            if (carte[rockford.Y, rockford.X] == Objet.T)
            {
                carte[rockford.Y, rockford.X] = Objet.V;
            }
            else if (carte[rockford.Y, rockford.X] == Objet.D)
            {
                carte[rockford.Y, rockford.X] = Objet.V;
                diam++;
            }
            return diam;
        }
        /// <summary>
        /// Trouves si un personnage est vivant
        /// </summary>
        /// <param name="carte">Le tableau du niveau</param>
        /// <param name="rockford">Le personnage</param>
        /// <param name="papillon">L'ennemi</param>
        /// <returns></returns>
        static bool TrouverSiPersonnageVivant(Objet[,] carte, Personnage rockford, Personnage papillon)
        {
            if (carte[rockford.Y, rockford.X] == Objet.R
                    || carte[rockford.Y, rockford.X] == Objet.RT
                    || rockford.X == papillon.X && rockford.Y == papillon.Y)
            {
                return false;
            }
            else 
            { 
                return true; 
            }
        }


        //Code temporaire pour 2e niveau
        /// <summary>
        /// Initialise le niveau 2, un labyrinthe
        /// </summary>
        /// <param name="tab">Le tableau du niveau</param>
        /// <param name="Width">La largeur du tableau du niveau</param>
        /// <param name="Height">La longeur du tableau du niveau</param>
        static void InitialiserNiveau2(Objet[,] tab, int Width, int Height)
        {
            //Murs
            RemplirNivMurs(tab);

            //Terre
            PlacerTerre(tab, Width, Height);

            //Rochers
            PlacerRochers(tab, Width, Height);

            //Vide
            PlacerVide2(tab);
        }
        /// <summary>
        /// Remplis le niveau de murs
        /// </summary>
        /// <param name="tab">Le tableau représentant le niveau</param>
        static void RemplirNivMurs(Objet[,] tab)
        {
            for (int i = 0; i < tab.GetLength(0); i++)
            {
                for(int j = 0; j < tab.GetLength(1); j++)
                {
                    tab[i, j] = Objet.M;
                }
            }
        }
        /// <summary>
        /// Places la terre du niveau dans le tableau
        /// </summary>
        /// <param name="tab">Le tableau représentant le niveau</param>
        /// <param name="NbrX">Le nombre de colonnes</param>
        /// <param name="NbrY">Le nombre de lignes</param>
        static void PlacerTerre(Objet[,] tab, int NbrX, int NbrY)
        {
            tab[16, 9] = Objet.T;
            tab[23, 9] = Objet.T;
        }
        /// <summary>
        /// Places les rochers du niveau dans le tableau
        /// </summary>
        /// <param name="tab">Le tableau représentant le niveau</param>
        /// <param name="NbrX">Le nombre de colonnes</param>
        /// <param name="NbrY">Le nombre de lignes</param>
        static void PlacerRochers(Objet[,] tab, int NbrX, int NbrY)
        {
            tab[16, 8] = Objet.R;
            tab[23, 8] = Objet.R;
        }
        /// <summary>
        /// Places le vide dans le tableau du niveau 2
        /// </summary>
        /// <param name="tab">Le tableau du niveau</param>
        static void PlacerVide2(Objet[,] tab)
        {
            //Met du vide pour la ligne extérieure (papillon)
            for (int i = 1; i <= 38; i++)
            {
                tab[i, 1] = Objet.V;
                tab[i, 20] = Objet.V;
            }
            for (int i = 2; i <= 19; i++)
            {
                tab[1, i] = Objet.V;
                tab[38, i] = Objet.V;
            }
        }
    }
}
